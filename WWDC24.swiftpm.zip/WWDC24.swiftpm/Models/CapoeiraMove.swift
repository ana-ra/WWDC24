

struct MovementModel {
    let name: String
    let imageName: String
    let selectedImageName: String
    var isSelected: Bool = false
}
