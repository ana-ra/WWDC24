

struct InstrumentModel {
    let name: String
    let imageName: String
    let selectedImageName: String
    let soundFileName: String
    var isSelected: Bool = false
}
