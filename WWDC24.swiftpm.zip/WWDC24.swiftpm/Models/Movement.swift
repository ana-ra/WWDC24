
struct MovementsModel {
    let id: Int
    let imageName: String
    var isSelected: Bool = false
}
