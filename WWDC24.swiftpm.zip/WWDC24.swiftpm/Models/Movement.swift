
struct MovementsModel {
    var id: Int
    var imageName: String
    var isSelected: Bool
    var name: String 
}
